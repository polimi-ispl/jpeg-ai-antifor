put high-quality training images into here
