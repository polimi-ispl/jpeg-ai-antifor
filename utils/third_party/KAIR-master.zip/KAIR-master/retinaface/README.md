This code is useful when you use `main_test_face_enhancement.py`.
